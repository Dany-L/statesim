clear all, close all
% analysis of trained hybrid model with doubly hyperdomininant multiplier
% compare l2 gain to static diagonal multiplier

cal_block_matrix_file_name = './data/HybridCRnn-10-8000000-False-MOSEK.mat';
config_file_name = './data/config-HybridCRnn-10-8000000-False-MOSEK.json';
norm_file_name = './data/HybridCRnn-10-8000000-False-MOSEK.json';


% load trained matrices
sys_matrices = load(cal_block_matrix_file_name);
par = sys_matrices.predictor_parameter;

% load configuration
config = jsondecode(fileread(config_file_name));
% load linearized system
A_lin = config.parameters.A_lin; B_lin=config.parameters.B_lin; C_lin = config.parameters.C_lin;

% size of caligraphic matices
nx = size(config.parameters.A_lin, 1); ny = nx; nu=nx;
nwp = size(config.parameters.B_lin, 2);
nzp = size(config.parameters.C_lin, 1);
nwu = config.parameters.nwu; nzu = nwu;

%% transformation from controller matrices to interconnected system
S_s = [A_lin, zeros(nx,nx), B_lin, zeros(nx,nwu);
    zeros(nx,nx+nx+nwp+nwu);
    C_lin, zeros(nzp,nx), zeros(nzp,nwp), zeros(nzp,nwu);
    zeros(nzu, nx+nx+nwp+nwu)];
S_l = [zeros(nx,nx), A_lin, zeros(nx,nzu);
    eye(nx), zeros(nx,nx), zeros(nx, nzu);
    zeros(nzp,nx), C_lin, zeros(nzp,nzu);
    zeros(nzu,nx), zeros(nzu,nx), eye(nzu)];
S_r = [zeros(nx,nx), eye(nx), zeros(nx,nwp), zeros(nx, nwu);
    zeros(nwp,nx), zeros(nwp,nx), eye(nwp), zeros(nwp, nwu);
    eye(nx), zeros(nx,nx), zeros(nx,nwp), zeros(nx,nwu);
    zeros(nwu, nx), zeros(nwu, nx), zeros(nwu,nwp), eye(nwu)];

P_bold = S_s + S_l * sys_matrices.omega * S_r;

A_cal = P_bold(1:nx*2, 1:nx*2);
B1_cal = P_bold(1:nx*2, nx*2+1:nx*2+nwp);
B2_cal = P_bold(1:nx*2, nx*2+1+nwp:end);

C1_cal = P_bold(nx*2+1: nx*2+nzp, 1:nx*2);
D11_cal = P_bold(nx*2+1:nx*2+nzp, nx*2+1:nx*2+nwp);
D12_cal = P_bold(nx*2+1:nx*2+nzp, nx*2+1+nwp:end);

C2_cal = P_bold(nx*2+nzp+1:end, 1:nx*2);
D21_cal = P_bold(nx*2+nzp+1:end, nx*2+1:nx*2+nwp);
D22_cal = P_bold(nx*2+nzp+1:end, nx*2+1+nwp:end);

%% Doubly hyperdominant multipliers
a=-1;b=1;
P_r = [b*eye(nwu) -eye(nwu);-a*eye(nwu) eye(nwu)];
lambda = sdpvar(nwu,1);

L = diag(lambda);

multiplier_constraint = [];
for idx = 1:1:nwu-1
    L = L - diag(sdpvar(nwu-idx,1), idx);
    L = L - diag(sdpvar(nwu-idx,1), -idx);
    multiplier_constraint = multiplier_constraint + (diag(L,idx) <= 0);
    multiplier_constraint = multiplier_constraint +(diag(L,-idx) <= 0);
end


P = P_r' * [zeros(nwu,nwu), L; L, zeros(nwu,nwu)] * P_r;

%% Lur'e system
L1 = [A_cal, B1_cal, B2_cal;
    eye(2*nx), zeros(2*nx, nwp), zeros(2*nx, nwu)];
L2 = [C1_cal, D11_cal, D12_cal;
    zeros(nwp, nx*2), eye(nwp), zeros(nwp, nwu)];
L3 = [C2_cal, D21_cal, D22_cal;
    zeros(nzu, nx*2), zeros(nzu, nwp), eye(nwu)];

X_cal = sdpvar(2*nx,2*nx);
ga = sdpvar(1,1);

eps=1e-5;

lmis = [];
lmi = L1' * [X_cal, zeros(2*nx,2*nx); zeros(2*nx,2*nx), -X_cal] * L1 + ...
    L2' * [eye(nwp), zeros(nwp,nzp); zeros(nzp,nwp), -ga*eye(nzp)] * L2 + ...
    L3' * P * L3;

lmis = lmis + (lmi <= -eps * eye(size(L1,2)));
lmis = lmis + (X_cal >= 0);
lmis = lmis + (ones(1,nwu)* L >= eps);
lmis = lmis + (L*ones(nwu,1) >= eps);
lmis = lmis + multiplier_constraint;

optimize(lmis, ga, sdpsettings('solver','MOSEK','verbose', 0))
checkset(lmis)
sqrt(double(ga))